-----------------------------------------------------------
------------ Made By ice.inmy.veins -----------------------
-----------------------------------------------------------


fx_version 'cerulean'

game 'gta5'

author "ice.inmy.veins"

description 'Gps per Valhalla RP [QBOX]'

client_scripts {
    "client.lua",
    "gpslist.lua"
}